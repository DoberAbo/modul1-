# aidana1moduls — University Course Management API

REST Web API на ASP.NET Core (.NET 8) для управления студентами, преподавателями, курсами и записями на курсы.
Предмет: CSE5032 Разработка веб-сервисов, Задание 1 (Модули 1-4).

## Запуск (Visual Studio 2022)
1. Открыть `aidana1moduls.sln`.
2. Нажать F5 (профиль `aidana1moduls`). Откроется Swagger: http://localhost:5080/swagger
3. При первом запуске база `UniversityDb` создаётся автоматически в SQL Server LocalDB и заполняется тестовыми данными.

Требования: Visual Studio 2022 с нагрузкой «ASP.NET и веб-разработка» (включает .NET 8 SDK и LocalDB).
Строка подключения — `appsettings.json` → `ConnectionStrings:DefaultConnection`.

## Архитектура
```
Client
  ↓ HTTP
Controllers  (маршрутизация, HTTP-коды, TraceId)
  ↓
Services     (бизнес-правила, логирование, ReturnResult<T>)
  ↓
Repositories (доступ к данным, IXxxRepository)
  ↓
Entity Framework Core (ApplicationDbContext)
  ↓
SQL Server (LocalDB)
```
Дополнительно: DTO + AutoMapper (`Mapping/MappingProfile`), `Middleware/ExceptionHandlingMiddleware` (централизованная обработка 500), Swagger.

## Endpoints
| Метод | URL | Описание |
|---|---|---|
| GET | /api/students | список студентов |
| GET | /api/students/{id} | студент по ID |
| GET | /api/students/{id}/courses | студент вместе с курсами |
| POST | /api/students | создать студента |
| PUT | /api/students/{id} | изменить студента |
| DELETE | /api/students/{id} | удалить студента |
| GET/POST | /api/teachers | список / создать преподавателя |
| GET/PUT/DELETE | /api/teachers/{id} | получить / изменить / удалить |
| GET | /api/courses?name=&teacherId=&minCredits=&maxCredits= | список курсов с фильтрацией |
| POST | /api/courses | создать курс (с привязкой к преподавателю) |
| GET/PUT/DELETE | /api/courses/{id} | получить / изменить / удалить |
| GET | /api/enrollments | список записей |
| GET | /api/enrollments/{id} | запись по ID |
| POST | /api/enrollments | записать студента на курс |
| PUT | /api/enrollments/{id}/grade | изменить оценку |
| DELETE | /api/enrollments/{id} | удалить студента с курса |

## Единый формат ответа
`ReturnResult<T>`: `statusCode, isSuccess, result, errorCode, errorMessage, traceId`.

## Бизнес-правила и коды
- Запись на несуществующий курс / студента → 404 `COURSE_NOT_FOUND` / `STUDENT_NOT_FOUND`
- Повторная запись на тот же курс → 409 `ALREADY_ENROLLED`
- Курс с несуществующим преподавателем → 404 `TEACHER_NOT_FOUND`
- Дубликат email → 409; ошибка валидации → 400 `VALIDATION_ERROR`; неожиданная ошибка → 500 `INTERNAL_SERVER_ERROR`
- Преподавателя с курсами удалить нельзя → 409 `TEACHER_HAS_COURSES`

## Конфигурация EF Core
Data Annotations (Student, Course, Enrollment-ключи по соглашению) + Fluent API (Teacher, индексы, связи, DeleteBehavior) + Conventions (PK `Id`).

## DI lifetime
Всё Scoped: `DbContext` живёт на время HTTP-запроса, поэтому репозитории и сервисы, которые его используют, тоже Scoped (Singleton нельзя — захват Scoped-зависимости).

## Логи
`ILogger`: Information (создание/изменение/удаление), Warning (объект не найден, конфликты), Error (необработанные исключения). Видны в окне Output / консоли Kestrel.

## Сценарии для защиты (Swagger)
1. GET /api/students → 2. POST /api/students → 3. GET /api/students/{id} → 4. PUT /api/students/{id} →
5. POST /api/teachers → 6. POST /api/courses (teacherId созданного) → 7. POST /api/enrollments →
8. тот же POST ещё раз (409) → 9. GET /api/students/{id}/courses → 10. GET /api/courses?minCredits=4 →
11. DELETE /api/enrollments/{id} → 12. GET /api/students/9999 (404) → 13. POST /api/students с пустым именем/плохим email (400) →
14-15. показать коды ответов и логи в Output.
