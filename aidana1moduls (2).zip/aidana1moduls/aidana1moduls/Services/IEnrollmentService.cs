using aidana1moduls.Common;
using aidana1moduls.DTO.Enrollments;

namespace aidana1moduls.Services;

public interface IEnrollmentService
{
    Task<ReturnResult<List<EnrollmentDto>>> GetAllAsync();
    Task<ReturnResult<EnrollmentDto>> GetByIdAsync(int id);
    Task<ReturnResult<EnrollmentDto>> CreateAsync(EnrollmentCreateDto dto);
    Task<ReturnResult<EnrollmentDto>> UpdateGradeAsync(int id, EnrollmentUpdateGradeDto dto);
    Task<ReturnResult<bool>> DeleteAsync(int id);
}
