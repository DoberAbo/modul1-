using aidana1moduls.Common;
using aidana1moduls.DTO.Teachers;

namespace aidana1moduls.Services;

public interface ITeacherService
{
    Task<ReturnResult<List<TeacherDto>>> GetAllAsync();
    Task<ReturnResult<TeacherDto>> GetByIdAsync(int id);
    Task<ReturnResult<TeacherDto>> CreateAsync(TeacherCreateDto dto);
    Task<ReturnResult<TeacherDto>> UpdateAsync(int id, TeacherUpdateDto dto);
    Task<ReturnResult<bool>> DeleteAsync(int id);
}
