using AutoMapper;
using aidana1moduls.Common;
using aidana1moduls.DTO.Teachers;
using aidana1moduls.Models;
using aidana1moduls.Repositories.Interfaces;

namespace aidana1moduls.Services;

public class TeacherService : ITeacherService
{
    private readonly ITeacherRepository _repo;
    private readonly IMapper _mapper;
    private readonly ILogger<TeacherService> _logger;

    public TeacherService(ITeacherRepository repo, IMapper mapper, ILogger<TeacherService> logger)
    {
        _repo = repo;
        _mapper = mapper;
        _logger = logger;
    }

    public async Task<ReturnResult<List<TeacherDto>>> GetAllAsync()
    {
        var teachers = await _repo.GetAllAsync();
        return ReturnResult.Ok(_mapper.Map<List<TeacherDto>>(teachers));
    }

    public async Task<ReturnResult<TeacherDto>> GetByIdAsync(int id)
    {
        var teacher = await _repo.GetByIdAsync(id);
        if (teacher == null)
        {
            _logger.LogWarning("Teacher with id {TeacherId} not found", id);
            return ReturnResult.Fail<TeacherDto>(404, "TEACHER_NOT_FOUND", "Teacher not found");
        }
        return ReturnResult.Ok(_mapper.Map<TeacherDto>(teacher));
    }

    public async Task<ReturnResult<TeacherDto>> CreateAsync(TeacherCreateDto dto)
    {
        if (await _repo.GetByEmailAsync(dto.Email) != null)
        {
            _logger.LogWarning("Attempt to create teacher with duplicate email {Email}", dto.Email);
            return ReturnResult.Fail<TeacherDto>(409, "TEACHER_EMAIL_EXISTS", "Teacher with this email already exists");
        }

        var teacher = _mapper.Map<Teacher>(dto);
        await _repo.AddAsync(teacher);

        _logger.LogInformation("Teacher created: Id={TeacherId}, Email={Email}", teacher.Id, teacher.Email);
        return ReturnResult.Created(_mapper.Map<TeacherDto>(teacher));
    }

    public async Task<ReturnResult<TeacherDto>> UpdateAsync(int id, TeacherUpdateDto dto)
    {
        var teacher = await _repo.GetByIdAsync(id);
        if (teacher == null)
        {
            _logger.LogWarning("Attempt to update non-existent teacher {TeacherId}", id);
            return ReturnResult.Fail<TeacherDto>(404, "TEACHER_NOT_FOUND", "Teacher not found");
        }

        var other = await _repo.GetByEmailAsync(dto.Email);
        if (other != null && other.Id != id)
        {
            _logger.LogWarning("Attempt to update teacher {TeacherId} with duplicate email {Email}", id, dto.Email);
            return ReturnResult.Fail<TeacherDto>(409, "TEACHER_EMAIL_EXISTS", "Teacher with this email already exists");
        }

        _mapper.Map(dto, teacher);
        await _repo.UpdateAsync(teacher);

        _logger.LogInformation("Teacher updated: Id={TeacherId}", id);
        return ReturnResult.Ok(_mapper.Map<TeacherDto>(teacher));
    }

    public async Task<ReturnResult<bool>> DeleteAsync(int id)
    {
        var teacher = await _repo.GetByIdAsync(id);
        if (teacher == null)
        {
            _logger.LogWarning("Attempt to delete non-existent teacher {TeacherId}", id);
            return ReturnResult.Fail<bool>(404, "TEACHER_NOT_FOUND", "Teacher not found");
        }

        if (await _repo.HasCoursesAsync(id))
        {
            _logger.LogWarning("Attempt to delete teacher {TeacherId} who still has courses", id);
            return ReturnResult.Fail<bool>(409, "TEACHER_HAS_COURSES", "Cannot delete teacher who has assigned courses");
        }

        await _repo.DeleteAsync(teacher);
        _logger.LogInformation("Teacher deleted: Id={TeacherId}", id);
        return ReturnResult.Ok(true);
    }
}
