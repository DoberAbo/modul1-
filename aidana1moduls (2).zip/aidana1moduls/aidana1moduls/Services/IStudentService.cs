using aidana1moduls.Common;
using aidana1moduls.DTO.Students;

namespace aidana1moduls.Services;

public interface IStudentService
{
    Task<ReturnResult<List<StudentDto>>> GetAllAsync();
    Task<ReturnResult<StudentDto>> GetByIdAsync(int id);
    Task<ReturnResult<StudentWithCoursesDto>> GetWithCoursesAsync(int id);
    Task<ReturnResult<StudentDto>> CreateAsync(StudentCreateDto dto);
    Task<ReturnResult<StudentDto>> UpdateAsync(int id, StudentUpdateDto dto);
    Task<ReturnResult<bool>> DeleteAsync(int id);
}
