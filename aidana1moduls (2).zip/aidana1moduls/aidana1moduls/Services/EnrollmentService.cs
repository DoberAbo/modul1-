using AutoMapper;
using aidana1moduls.Common;
using aidana1moduls.DTO.Enrollments;
using aidana1moduls.Models;
using aidana1moduls.Repositories.Interfaces;

namespace aidana1moduls.Services;

public class EnrollmentService : IEnrollmentService
{
    private readonly IEnrollmentRepository _repo;
    private readonly IStudentRepository _studentRepo;
    private readonly ICourseRepository _courseRepo;
    private readonly IMapper _mapper;
    private readonly ILogger<EnrollmentService> _logger;

    public EnrollmentService(IEnrollmentRepository repo, IStudentRepository studentRepo, ICourseRepository courseRepo,
        IMapper mapper, ILogger<EnrollmentService> logger)
    {
        _repo = repo;
        _studentRepo = studentRepo;
        _courseRepo = courseRepo;
        _mapper = mapper;
        _logger = logger;
    }

    public async Task<ReturnResult<List<EnrollmentDto>>> GetAllAsync()
    {
        var list = await _repo.GetAllAsync();
        return ReturnResult.Ok(_mapper.Map<List<EnrollmentDto>>(list));
    }

    public async Task<ReturnResult<EnrollmentDto>> GetByIdAsync(int id)
    {
        var enrollment = await _repo.GetByIdAsync(id);
        if (enrollment == null)
        {
            _logger.LogWarning("Enrollment with id {EnrollmentId} not found", id);
            return ReturnResult.Fail<EnrollmentDto>(404, "ENROLLMENT_NOT_FOUND", "Enrollment not found");
        }
        return ReturnResult.Ok(_mapper.Map<EnrollmentDto>(enrollment));
    }

    public async Task<ReturnResult<EnrollmentDto>> CreateAsync(EnrollmentCreateDto dto)
    {
        // Правило №2: несуществующий студент
        if (await _studentRepo.GetByIdAsync(dto.StudentId) == null)
        {
            _logger.LogWarning("Enrollment failed: student {StudentId} not found", dto.StudentId);
            return ReturnResult.Fail<EnrollmentDto>(404, "STUDENT_NOT_FOUND", "Student not found");
        }

        // Правило №1: несуществующий курс
        if (await _courseRepo.GetByIdAsync(dto.CourseId) == null)
        {
            _logger.LogWarning("Enrollment failed: course {CourseId} not found", dto.CourseId);
            return ReturnResult.Fail<EnrollmentDto>(404, "COURSE_NOT_FOUND", "Course not found");
        }

        // Правило №3: повторная запись
        if (await _repo.ExistsAsync(dto.StudentId, dto.CourseId))
        {
            _logger.LogWarning("Enrollment failed: student {StudentId} already enrolled in course {CourseId}", dto.StudentId, dto.CourseId);
            return ReturnResult.Fail<EnrollmentDto>(409, "ALREADY_ENROLLED", "Student is already enrolled in this course");
        }

        var enrollment = new Enrollment
        {
            StudentId = dto.StudentId,
            CourseId = dto.CourseId,
            EnrollmentDate = DateTime.UtcNow
        };
        await _repo.AddAsync(enrollment);

        _logger.LogInformation("Enrollment created: Id={EnrollmentId}, StudentId={StudentId}, CourseId={CourseId}",
            enrollment.Id, dto.StudentId, dto.CourseId);

        var created = await _repo.GetByIdAsync(enrollment.Id);
        return ReturnResult.Created(_mapper.Map<EnrollmentDto>(created));
    }

    public async Task<ReturnResult<EnrollmentDto>> UpdateGradeAsync(int id, EnrollmentUpdateGradeDto dto)
    {
        var enrollment = await _repo.GetByIdAsync(id);
        if (enrollment == null)
        {
            _logger.LogWarning("Attempt to update grade of non-existent enrollment {EnrollmentId}", id);
            return ReturnResult.Fail<EnrollmentDto>(404, "ENROLLMENT_NOT_FOUND", "Enrollment not found");
        }

        enrollment.Grade = dto.Grade;
        await _repo.UpdateAsync(enrollment);

        _logger.LogInformation("Enrollment grade updated: Id={EnrollmentId}, Grade={Grade}", id, dto.Grade);
        return ReturnResult.Ok(_mapper.Map<EnrollmentDto>(enrollment));
    }

    public async Task<ReturnResult<bool>> DeleteAsync(int id)
    {
        var enrollment = await _repo.GetByIdAsync(id);
        if (enrollment == null)
        {
            _logger.LogWarning("Attempt to delete non-existent enrollment {EnrollmentId}", id);
            return ReturnResult.Fail<bool>(404, "ENROLLMENT_NOT_FOUND", "Enrollment not found");
        }

        await _repo.DeleteAsync(enrollment);
        _logger.LogInformation("Enrollment deleted: Id={EnrollmentId}", id);
        return ReturnResult.Ok(true);
    }
}
