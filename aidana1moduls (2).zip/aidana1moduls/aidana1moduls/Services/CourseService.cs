using AutoMapper;
using aidana1moduls.Common;
using aidana1moduls.DTO.Courses;
using aidana1moduls.Models;
using aidana1moduls.Repositories.Interfaces;

namespace aidana1moduls.Services;

public class CourseService : ICourseService
{
    private readonly ICourseRepository _repo;
    private readonly ITeacherRepository _teacherRepo;
    private readonly IMapper _mapper;
    private readonly ILogger<CourseService> _logger;

    public CourseService(ICourseRepository repo, ITeacherRepository teacherRepo, IMapper mapper, ILogger<CourseService> logger)
    {
        _repo = repo;
        _teacherRepo = teacherRepo;
        _mapper = mapper;
        _logger = logger;
    }

    public async Task<ReturnResult<List<CourseDto>>> GetAllAsync(string? name, int? teacherId, int? minCredits, int? maxCredits)
    {
        if (minCredits.HasValue && maxCredits.HasValue && minCredits > maxCredits)
            return ReturnResult.Fail<List<CourseDto>>(400, "VALIDATION_ERROR", "minCredits не может быть больше maxCredits");

        var courses = await _repo.GetFilteredAsync(name, teacherId, minCredits, maxCredits);
        return ReturnResult.Ok(_mapper.Map<List<CourseDto>>(courses));
    }

    public async Task<ReturnResult<CourseDto>> GetByIdAsync(int id)
    {
        var course = await _repo.GetByIdAsync(id);
        if (course == null)
        {
            _logger.LogWarning("Course with id {CourseId} not found", id);
            return ReturnResult.Fail<CourseDto>(404, "COURSE_NOT_FOUND", "Course not found");
        }
        return ReturnResult.Ok(_mapper.Map<CourseDto>(course));
    }

    public async Task<ReturnResult<CourseDto>> CreateAsync(CourseCreateDto dto)
    {
        // Правило №4: курс не может ссылаться на несуществующего преподавателя
        if (await _teacherRepo.GetByIdAsync(dto.TeacherId) == null)
        {
            _logger.LogWarning("Attempt to create course with non-existent teacher {TeacherId}", dto.TeacherId);
            return ReturnResult.Fail<CourseDto>(404, "TEACHER_NOT_FOUND", "Teacher not found");
        }

        var course = _mapper.Map<Course>(dto);
        course.CreatedAt = DateTime.UtcNow;
        await _repo.AddAsync(course);

        _logger.LogInformation("Course created: Id={CourseId}, Name={Name}, TeacherId={TeacherId}", course.Id, course.Name, course.TeacherId);

        var created = await _repo.GetByIdAsync(course.Id); // с подгруженным преподавателем
        return ReturnResult.Created(_mapper.Map<CourseDto>(created));
    }

    public async Task<ReturnResult<CourseDto>> UpdateAsync(int id, CourseUpdateDto dto)
    {
        var course = await _repo.GetByIdAsync(id);
        if (course == null)
        {
            _logger.LogWarning("Attempt to update non-existent course {CourseId}", id);
            return ReturnResult.Fail<CourseDto>(404, "COURSE_NOT_FOUND", "Course not found");
        }

        if (await _teacherRepo.GetByIdAsync(dto.TeacherId) == null)
        {
            _logger.LogWarning("Attempt to assign non-existent teacher {TeacherId} to course {CourseId}", dto.TeacherId, id);
            return ReturnResult.Fail<CourseDto>(404, "TEACHER_NOT_FOUND", "Teacher not found");
        }

        _mapper.Map(dto, course);
        await _repo.UpdateAsync(course);

        _logger.LogInformation("Course updated: Id={CourseId}", id);

        var updated = await _repo.GetByIdAsync(id);
        return ReturnResult.Ok(_mapper.Map<CourseDto>(updated));
    }

    public async Task<ReturnResult<bool>> DeleteAsync(int id)
    {
        var course = await _repo.GetByIdAsync(id);
        if (course == null)
        {
            _logger.LogWarning("Attempt to delete non-existent course {CourseId}", id);
            return ReturnResult.Fail<bool>(404, "COURSE_NOT_FOUND", "Course not found");
        }

        await _repo.DeleteAsync(course);
        _logger.LogInformation("Course deleted: Id={CourseId}", id);
        return ReturnResult.Ok(true);
    }
}
