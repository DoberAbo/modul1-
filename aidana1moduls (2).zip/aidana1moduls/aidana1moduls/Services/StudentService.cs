using AutoMapper;
using aidana1moduls.Common;
using aidana1moduls.DTO.Students;
using aidana1moduls.Models;
using aidana1moduls.Repositories.Interfaces;

namespace aidana1moduls.Services;

public class StudentService : IStudentService
{
    private readonly IStudentRepository _repo;
    private readonly IMapper _mapper;
    private readonly ILogger<StudentService> _logger;

    public StudentService(IStudentRepository repo, IMapper mapper, ILogger<StudentService> logger)
    {
        _repo = repo;
        _mapper = mapper;
        _logger = logger;
    }

    public async Task<ReturnResult<List<StudentDto>>> GetAllAsync()
    {
        var students = await _repo.GetAllAsync();
        return ReturnResult.Ok(_mapper.Map<List<StudentDto>>(students));
    }

    public async Task<ReturnResult<StudentDto>> GetByIdAsync(int id)
    {
        var student = await _repo.GetByIdAsync(id);
        if (student == null)
        {
            _logger.LogWarning("Student with id {StudentId} not found", id);
            return ReturnResult.Fail<StudentDto>(404, "STUDENT_NOT_FOUND", "Student not found");
        }
        return ReturnResult.Ok(_mapper.Map<StudentDto>(student));
    }

    public async Task<ReturnResult<StudentWithCoursesDto>> GetWithCoursesAsync(int id)
    {
        var student = await _repo.GetWithCoursesAsync(id);
        if (student == null)
        {
            _logger.LogWarning("Student with id {StudentId} not found (with courses)", id);
            return ReturnResult.Fail<StudentWithCoursesDto>(404, "STUDENT_NOT_FOUND", "Student not found");
        }
        return ReturnResult.Ok(_mapper.Map<StudentWithCoursesDto>(student));
    }

    public async Task<ReturnResult<StudentDto>> CreateAsync(StudentCreateDto dto)
    {
        if (dto.BirthDate!.Value.Date >= DateTime.UtcNow.Date)
            return ReturnResult.Fail<StudentDto>(400, "VALIDATION_ERROR", "Дата рождения должна быть в прошлом");

        if (await _repo.GetByEmailAsync(dto.Email) != null)
        {
            _logger.LogWarning("Attempt to create student with duplicate email {Email}", dto.Email);
            return ReturnResult.Fail<StudentDto>(409, "STUDENT_EMAIL_EXISTS", "Student with this email already exists");
        }

        var student = _mapper.Map<Student>(dto);
        student.CreatedAt = DateTime.UtcNow;
        await _repo.AddAsync(student);

        _logger.LogInformation("Student created: Id={StudentId}, Email={Email}", student.Id, student.Email);
        return ReturnResult.Created(_mapper.Map<StudentDto>(student));
    }

    public async Task<ReturnResult<StudentDto>> UpdateAsync(int id, StudentUpdateDto dto)
    {
        var student = await _repo.GetByIdAsync(id);
        if (student == null)
        {
            _logger.LogWarning("Attempt to update non-existent student {StudentId}", id);
            return ReturnResult.Fail<StudentDto>(404, "STUDENT_NOT_FOUND", "Student not found");
        }

        if (dto.BirthDate!.Value.Date >= DateTime.UtcNow.Date)
            return ReturnResult.Fail<StudentDto>(400, "VALIDATION_ERROR", "Дата рождения должна быть в прошлом");

        var other = await _repo.GetByEmailAsync(dto.Email);
        if (other != null && other.Id != id)
        {
            _logger.LogWarning("Attempt to update student {StudentId} with duplicate email {Email}", id, dto.Email);
            return ReturnResult.Fail<StudentDto>(409, "STUDENT_EMAIL_EXISTS", "Student with this email already exists");
        }

        _mapper.Map(dto, student);
        await _repo.UpdateAsync(student);

        _logger.LogInformation("Student updated: Id={StudentId}", id);
        return ReturnResult.Ok(_mapper.Map<StudentDto>(student));
    }

    public async Task<ReturnResult<bool>> DeleteAsync(int id)
    {
        var student = await _repo.GetByIdAsync(id);
        if (student == null)
        {
            _logger.LogWarning("Attempt to delete non-existent student {StudentId}", id);
            return ReturnResult.Fail<bool>(404, "STUDENT_NOT_FOUND", "Student not found");
        }

        await _repo.DeleteAsync(student);
        _logger.LogInformation("Student deleted: Id={StudentId}", id);
        return ReturnResult.Ok(true);
    }
}
