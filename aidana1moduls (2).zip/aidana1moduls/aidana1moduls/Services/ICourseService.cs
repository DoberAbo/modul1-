using aidana1moduls.Common;
using aidana1moduls.DTO.Courses;

namespace aidana1moduls.Services;

public interface ICourseService
{
    Task<ReturnResult<List<CourseDto>>> GetAllAsync(string? name, int? teacherId, int? minCredits, int? maxCredits);
    Task<ReturnResult<CourseDto>> GetByIdAsync(int id);
    Task<ReturnResult<CourseDto>> CreateAsync(CourseCreateDto dto);
    Task<ReturnResult<CourseDto>> UpdateAsync(int id, CourseUpdateDto dto);
    Task<ReturnResult<bool>> DeleteAsync(int id);
}
