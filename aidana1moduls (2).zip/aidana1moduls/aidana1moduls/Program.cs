using aidana1moduls.Common;
using aidana1moduls.Data;
using aidana1moduls.Mapping;
using aidana1moduls.Middleware;
using aidana1moduls.Repositories.Implementations;
using aidana1moduls.Repositories.Interfaces;
using aidana1moduls.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Controllers + единый формат ошибок валидации (400)
builder.Services.AddControllers()
    .ConfigureApiBehaviorOptions(options =>
    {
        options.InvalidModelStateResponseFactory = context =>
        {
            var errors = context.ModelState
                .Where(x => x.Value != null && x.Value.Errors.Count > 0)
                .SelectMany(x => x.Value!.Errors.Select(e =>
                    string.IsNullOrWhiteSpace(e.ErrorMessage) ? $"{x.Key}: invalid value" : e.ErrorMessage));

            var result = ReturnResult.Fail<object>(400, "VALIDATION_ERROR", string.Join("; ", errors));
            result.TraceId = context.HttpContext.TraceIdentifier;
            return new ObjectResult(result) { StatusCode = StatusCodes.Status400BadRequest };
        };
    });

// EF Core + SQL Server (LocalDB)
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// AutoMapper
builder.Services.AddAutoMapper(typeof(MappingProfile));

// Dependency Injection. Scoped: один экземпляр на HTTP-запрос,
// т.к. DbContext тоже Scoped, а репозитории/сервисы зависят от него.
builder.Services.AddScoped<IStudentRepository, StudentRepository>();
builder.Services.AddScoped<ITeacherRepository, TeacherRepository>();
builder.Services.AddScoped<ICourseRepository, CourseRepository>();
builder.Services.AddScoped<IEnrollmentRepository, EnrollmentRepository>();

builder.Services.AddScoped<IStudentService, StudentService>();
builder.Services.AddScoped<ITeacherService, TeacherService>();
builder.Services.AddScoped<ICourseService, CourseService>();
builder.Services.AddScoped<IEnrollmentService, EnrollmentService>();

// Swagger
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new() { Title = "University Course Management API", Version = "v1" });
});

var app = builder.Build();

// Создание БД и тестовые данные при первом запуске
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
    db.Database.EnsureCreated();
    DbSeeder.Seed(db);
}

app.UseMiddleware<ExceptionHandlingMiddleware>();

app.UseSwagger();
app.UseSwaggerUI();

app.MapControllers();

app.Run();
