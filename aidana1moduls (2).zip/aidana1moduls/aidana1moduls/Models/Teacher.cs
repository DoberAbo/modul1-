namespace aidana1moduls.Models;

// Конфигурация этой сущности (обязательные поля, длины) задана через Fluent API в ApplicationDbContext
public class Teacher
{
    public int Id { get; set; }
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Department { get; set; } = string.Empty;

    public ICollection<Course> Courses { get; set; } = new List<Course>();
}
