namespace aidana1moduls.Models;

public class Enrollment
{
    public int Id { get; set; }

    public int StudentId { get; set; }
    public Student Student { get; set; } = null!;

    public int CourseId { get; set; }
    public Course Course { get; set; } = null!;

    public DateTime EnrollmentDate { get; set; } = DateTime.UtcNow;

    /// <summary>Оценка 0-100, null если ещё не выставлена.</summary>
    public int? Grade { get; set; }
}
