using aidana1moduls.Common;
using aidana1moduls.DTO.Students;
using aidana1moduls.Services;
using Microsoft.AspNetCore.Mvc;

namespace aidana1moduls.Controllers;

[Route("api/students")]
public class StudentsController : BaseApiController
{
    private readonly IStudentService _service;

    public StudentsController(IStudentService service) => _service = service;

    /// <summary>Получить всех студентов</summary>
    [HttpGet]
    [ProducesResponseType(typeof(ReturnResult<List<StudentDto>>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAll() => Send(await _service.GetAllAsync());

    /// <summary>Получить студента по ID</summary>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(ReturnResult<StudentDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetById(int id) => Send(await _service.GetByIdAsync(id));

    /// <summary>Получить студента вместе с его курсами</summary>
    [HttpGet("{id:int}/courses")]
    [ProducesResponseType(typeof(ReturnResult<StudentWithCoursesDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetWithCourses(int id) => Send(await _service.GetWithCoursesAsync(id));

    /// <summary>Создать студента</summary>
    [HttpPost]
    [ProducesResponseType(typeof(ReturnResult<StudentDto>), StatusCodes.Status201Created)]
    public async Task<IActionResult> Create([FromBody] StudentCreateDto dto) => Send(await _service.CreateAsync(dto));

    /// <summary>Изменить студента</summary>
    [HttpPut("{id:int}")]
    [ProducesResponseType(typeof(ReturnResult<StudentDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> Update(int id, [FromBody] StudentUpdateDto dto) => Send(await _service.UpdateAsync(id, dto));

    /// <summary>Удалить студента</summary>
    [HttpDelete("{id:int}")]
    [ProducesResponseType(typeof(ReturnResult<bool>), StatusCodes.Status200OK)]
    public async Task<IActionResult> Delete(int id) => Send(await _service.DeleteAsync(id));
}
