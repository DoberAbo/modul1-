using aidana1moduls.Common;
using Microsoft.AspNetCore.Mvc;

namespace aidana1moduls.Controllers;

[ApiController]
[Produces("application/json")]
[ProducesResponseType(typeof(ReturnResult<object>), StatusCodes.Status400BadRequest)]
[ProducesResponseType(typeof(ReturnResult<object>), StatusCodes.Status404NotFound)]
[ProducesResponseType(typeof(ReturnResult<object>), StatusCodes.Status409Conflict)]
[ProducesResponseType(typeof(ReturnResult<object>), StatusCodes.Status500InternalServerError)]
public abstract class BaseApiController : ControllerBase
{
    /// <summary>Превращает ReturnResult в HTTP-ответ с нужным статус-кодом и TraceId.</summary>
    protected IActionResult Send<T>(ReturnResult<T> result)
    {
        result.TraceId = HttpContext.TraceIdentifier;
        return StatusCode(result.StatusCode, result);
    }
}
