using aidana1moduls.Common;
using aidana1moduls.DTO.Courses;
using aidana1moduls.Services;
using Microsoft.AspNetCore.Mvc;

namespace aidana1moduls.Controllers;

[Route("api/courses")]
public class CoursesController : BaseApiController
{
    private readonly ICourseService _service;

    public CoursesController(ICourseService service) => _service = service;

    /// <summary>Получить курсы (с фильтрацией по названию, преподавателю и кредитам)</summary>
    [HttpGet]
    [ProducesResponseType(typeof(ReturnResult<List<CourseDto>>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAll([FromQuery] string? name, [FromQuery] int? teacherId,
        [FromQuery] int? minCredits, [FromQuery] int? maxCredits)
        => Send(await _service.GetAllAsync(name, teacherId, minCredits, maxCredits));

    /// <summary>Получить курс по ID</summary>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(ReturnResult<CourseDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetById(int id) => Send(await _service.GetByIdAsync(id));

    /// <summary>Создать курс и закрепить за преподавателем</summary>
    [HttpPost]
    [ProducesResponseType(typeof(ReturnResult<CourseDto>), StatusCodes.Status201Created)]
    public async Task<IActionResult> Create([FromBody] CourseCreateDto dto) => Send(await _service.CreateAsync(dto));

    /// <summary>Изменить курс</summary>
    [HttpPut("{id:int}")]
    [ProducesResponseType(typeof(ReturnResult<CourseDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> Update(int id, [FromBody] CourseUpdateDto dto) => Send(await _service.UpdateAsync(id, dto));

    /// <summary>Удалить курс</summary>
    [HttpDelete("{id:int}")]
    [ProducesResponseType(typeof(ReturnResult<bool>), StatusCodes.Status200OK)]
    public async Task<IActionResult> Delete(int id) => Send(await _service.DeleteAsync(id));
}
