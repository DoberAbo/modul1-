using aidana1moduls.Common;
using aidana1moduls.DTO.Enrollments;
using aidana1moduls.Services;
using Microsoft.AspNetCore.Mvc;

namespace aidana1moduls.Controllers;

[Route("api/enrollments")]
public class EnrollmentsController : BaseApiController
{
    private readonly IEnrollmentService _service;

    public EnrollmentsController(IEnrollmentService service) => _service = service;

    /// <summary>Получить список записей</summary>
    [HttpGet]
    [ProducesResponseType(typeof(ReturnResult<List<EnrollmentDto>>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAll() => Send(await _service.GetAllAsync());

    /// <summary>Получить запись по ID</summary>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(ReturnResult<EnrollmentDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetById(int id) => Send(await _service.GetByIdAsync(id));

    /// <summary>Записать студента на курс</summary>
    [HttpPost]
    [ProducesResponseType(typeof(ReturnResult<EnrollmentDto>), StatusCodes.Status201Created)]
    public async Task<IActionResult> Create([FromBody] EnrollmentCreateDto dto) => Send(await _service.CreateAsync(dto));

    /// <summary>Изменить оценку студента</summary>
    [HttpPut("{id:int}/grade")]
    [ProducesResponseType(typeof(ReturnResult<EnrollmentDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> UpdateGrade(int id, [FromBody] EnrollmentUpdateGradeDto dto)
        => Send(await _service.UpdateGradeAsync(id, dto));

    /// <summary>Удалить студента с курса</summary>
    [HttpDelete("{id:int}")]
    [ProducesResponseType(typeof(ReturnResult<bool>), StatusCodes.Status200OK)]
    public async Task<IActionResult> Delete(int id) => Send(await _service.DeleteAsync(id));
}
