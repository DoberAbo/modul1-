namespace aidana1moduls.Common;

/// <summary>Единый формат ответа API.</summary>
public class ReturnResult<T>
{
    public int StatusCode { get; set; }
    public bool IsSuccess { get; set; }
    public T? Result { get; set; }
    public string? ErrorCode { get; set; }
    public string? ErrorMessage { get; set; }
    public string? TraceId { get; set; }
}

/// <summary>Фабричные методы для создания ReturnResult&lt;T&gt;.</summary>
public static class ReturnResult
{
    public static ReturnResult<T> Ok<T>(T result) =>
        new() { StatusCode = 200, IsSuccess = true, Result = result };

    public static ReturnResult<T> Created<T>(T result) =>
        new() { StatusCode = 201, IsSuccess = true, Result = result };

    public static ReturnResult<T> Fail<T>(int statusCode, string errorCode, string message) =>
        new() { StatusCode = statusCode, IsSuccess = false, ErrorCode = errorCode, ErrorMessage = message };
}
