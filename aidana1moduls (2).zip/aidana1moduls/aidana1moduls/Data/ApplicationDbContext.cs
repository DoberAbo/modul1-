using aidana1moduls.Models;
using Microsoft.EntityFrameworkCore;

namespace aidana1moduls.Data;

public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

    public DbSet<Student> Students => Set<Student>();
    public DbSet<Teacher> Teachers => Set<Teacher>();
    public DbSet<Course> Courses => Set<Course>();
    public DbSet<Enrollment> Enrollments => Set<Enrollment>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // Student: часть настроек через Data Annotations (в классе), уникальность - Fluent API
        modelBuilder.Entity<Student>(e =>
        {
            e.HasKey(s => s.Id);
            e.HasIndex(s => s.Email).IsUnique();
        });

        // Teacher: полностью через Fluent API
        modelBuilder.Entity<Teacher>(e =>
        {
            e.HasKey(t => t.Id);
            e.Property(t => t.FirstName).IsRequired().HasMaxLength(100);
            e.Property(t => t.LastName).IsRequired().HasMaxLength(100);
            e.Property(t => t.Email).IsRequired().HasMaxLength(200);
            e.Property(t => t.Department).IsRequired().HasMaxLength(150);
            e.HasIndex(t => t.Email).IsUnique();
        });

        // Course -> Teacher (многие к одному), нельзя удалить преподавателя с курсами
        modelBuilder.Entity<Course>(e =>
        {
            e.HasOne(c => c.Teacher)
             .WithMany(t => t.Courses)
             .HasForeignKey(c => c.TeacherId)
             .OnDelete(DeleteBehavior.Restrict);
        });

        // Enrollment: связь многие-ко-многим Student <-> Course
        modelBuilder.Entity<Enrollment>(e =>
        {
            e.HasOne(x => x.Student)
             .WithMany(s => s.Enrollments)
             .HasForeignKey(x => x.StudentId)
             .OnDelete(DeleteBehavior.Cascade);

            e.HasOne(x => x.Course)
             .WithMany(c => c.Enrollments)
             .HasForeignKey(x => x.CourseId)
             .OnDelete(DeleteBehavior.Cascade);

            // Один студент - один раз на один курс
            e.HasIndex(x => new { x.StudentId, x.CourseId }).IsUnique();
        });
    }
}
