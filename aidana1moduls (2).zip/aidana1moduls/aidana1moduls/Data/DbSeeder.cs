using aidana1moduls.Models;

namespace aidana1moduls.Data;

/// <summary>Тестовые данные (заполняются один раз, если база пустая).</summary>
public static class DbSeeder
{
    public static void Seed(ApplicationDbContext db)
    {
        if (db.Teachers.Any()) return;

        var t1 = new Teacher { FirstName = "Elena", LastName = "Gertsen", Email = "gertsen@university.kz", Department = "Software Engineering" };
        var t2 = new Teacher { FirstName = "Farida", LastName = "Abdoldina", Email = "abdoldina@university.kz", Department = "Computer Science" };
        db.Teachers.AddRange(t1, t2);

        var s1 = new Student { FirstName = "Alex", LastName = "Smith", Email = "alex.smith@student.kz", BirthDate = new DateTime(2003, 5, 12) };
        var s2 = new Student { FirstName = "Aidana", LastName = "Nurlan", Email = "aidana.nurlan@student.kz", BirthDate = new DateTime(2004, 2, 3) };
        var s3 = new Student { FirstName = "Marat", LastName = "Serik", Email = "marat.serik@student.kz", BirthDate = new DateTime(2003, 11, 21) };
        db.Students.AddRange(s1, s2, s3);

        var c1 = new Course { Name = "Web Services", Description = "REST API на ASP.NET Core", Credits = 5, Teacher = t1 };
        var c2 = new Course { Name = "Databases", Description = "Реляционные базы данных и SQL", Credits = 4, Teacher = t2 };
        var c3 = new Course { Name = "Algorithms", Description = "Алгоритмы и структуры данных", Credits = 6, Teacher = t2 };
        db.Courses.AddRange(c1, c2, c3);

        db.Enrollments.AddRange(
            new Enrollment { Student = s1, Course = c1, Grade = 90 },
            new Enrollment { Student = s1, Course = c2 },
            new Enrollment { Student = s2, Course = c1, Grade = 85 }
        );

        db.SaveChanges();
    }
}
