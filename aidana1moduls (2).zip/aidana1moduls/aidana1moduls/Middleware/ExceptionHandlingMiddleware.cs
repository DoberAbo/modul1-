using System.Text.Json;
using aidana1moduls.Common;

namespace aidana1moduls.Middleware;

/// <summary>Централизованная обработка непредвиденных ошибок.</summary>
public class ExceptionHandlingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<ExceptionHandlingMiddleware> _logger;

    public ExceptionHandlingMiddleware(RequestDelegate next, ILogger<ExceptionHandlingMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (Exception ex)
        {
            // Подробности - только в лог
            _logger.LogError(ex, "Unhandled exception. TraceId: {TraceId}, Path: {Path}",
                context.TraceIdentifier, context.Request.Path);

            // Пользователю - только безопасный ответ
            var result = ReturnResult.Fail<object>(500, "INTERNAL_SERVER_ERROR", "An unexpected error occurred");
            result.TraceId = context.TraceIdentifier;

            context.Response.Clear();
            context.Response.StatusCode = StatusCodes.Status500InternalServerError;
            context.Response.ContentType = "application/json";
            await context.Response.WriteAsync(JsonSerializer.Serialize(result,
                new JsonSerializerOptions(JsonSerializerDefaults.Web)));
        }
    }
}
