using AutoMapper;
using aidana1moduls.DTO.Courses;
using aidana1moduls.DTO.Enrollments;
using aidana1moduls.DTO.Students;
using aidana1moduls.DTO.Teachers;
using aidana1moduls.Models;

namespace aidana1moduls.Mapping;

public class MappingProfile : Profile
{
    public MappingProfile()
    {
        // Student
        CreateMap<Student, StudentDto>();
        CreateMap<StudentCreateDto, Student>();
        CreateMap<StudentUpdateDto, Student>();
        CreateMap<Student, StudentWithCoursesDto>()
            .ForMember(d => d.Courses, o => o.MapFrom(s => s.Enrollments));
        CreateMap<Enrollment, EnrolledCourseDto>()
            .ForMember(d => d.EnrollmentId, o => o.MapFrom(e => e.Id))
            .ForMember(d => d.CourseName, o => o.MapFrom(e => e.Course.Name))
            .ForMember(d => d.Credits, o => o.MapFrom(e => e.Course.Credits));

        // Teacher
        CreateMap<Teacher, TeacherDto>();
        CreateMap<TeacherCreateDto, Teacher>();
        CreateMap<TeacherUpdateDto, Teacher>();

        // Course
        CreateMap<Course, CourseDto>()
            .ForMember(d => d.TeacherName, o => o.MapFrom(c => c.Teacher.FirstName + " " + c.Teacher.LastName));
        CreateMap<CourseCreateDto, Course>();
        CreateMap<CourseUpdateDto, Course>();

        // Enrollment
        CreateMap<Enrollment, EnrollmentDto>()
            .ForMember(d => d.StudentName, o => o.MapFrom(e => e.Student.FirstName + " " + e.Student.LastName))
            .ForMember(d => d.CourseName, o => o.MapFrom(e => e.Course.Name));
    }
}
