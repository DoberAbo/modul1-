using aidana1moduls.Data;
using aidana1moduls.Models;
using aidana1moduls.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace aidana1moduls.Repositories.Implementations;

public class EnrollmentRepository : Repository<Enrollment>, IEnrollmentRepository
{
    public EnrollmentRepository(ApplicationDbContext db) : base(db) { }

    public override async Task<List<Enrollment>> GetAllAsync() =>
        await _db.Enrollments.AsNoTracking()
            .Include(e => e.Student).Include(e => e.Course)
            .OrderBy(e => e.Id).ToListAsync();

    public override async Task<Enrollment?> GetByIdAsync(int id) =>
        await _db.Enrollments
            .Include(e => e.Student).Include(e => e.Course)
            .FirstOrDefaultAsync(e => e.Id == id);

    public async Task<bool> ExistsAsync(int studentId, int courseId) =>
        await _db.Enrollments.AnyAsync(e => e.StudentId == studentId && e.CourseId == courseId);
}
