using aidana1moduls.Data;
using aidana1moduls.Models;
using aidana1moduls.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace aidana1moduls.Repositories.Implementations;

public class TeacherRepository : Repository<Teacher>, ITeacherRepository
{
    public TeacherRepository(ApplicationDbContext db) : base(db) { }

    public async Task<Teacher?> GetByEmailAsync(string email) =>
        await _db.Teachers.AsNoTracking().FirstOrDefaultAsync(t => t.Email == email);

    public async Task<bool> HasCoursesAsync(int teacherId) =>
        await _db.Courses.AnyAsync(c => c.TeacherId == teacherId);
}
