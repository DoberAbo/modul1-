using aidana1moduls.Data;
using aidana1moduls.Models;
using aidana1moduls.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace aidana1moduls.Repositories.Implementations;

public class StudentRepository : Repository<Student>, IStudentRepository
{
    public StudentRepository(ApplicationDbContext db) : base(db) { }

    public async Task<Student?> GetByEmailAsync(string email) =>
        await _db.Students.AsNoTracking().FirstOrDefaultAsync(s => s.Email == email);

    public async Task<Student?> GetWithCoursesAsync(int id) =>
        await _db.Students
            .AsNoTracking()
            .Include(s => s.Enrollments).ThenInclude(e => e.Course)
            .FirstOrDefaultAsync(s => s.Id == id);
}
