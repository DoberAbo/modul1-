using aidana1moduls.Data;
using aidana1moduls.Models;
using aidana1moduls.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace aidana1moduls.Repositories.Implementations;

public class CourseRepository : Repository<Course>, ICourseRepository
{
    public CourseRepository(ApplicationDbContext db) : base(db) { }

    public override async Task<List<Course>> GetAllAsync() =>
        await _db.Courses.AsNoTracking().Include(c => c.Teacher).OrderBy(c => c.Id).ToListAsync();

    public override async Task<Course?> GetByIdAsync(int id) =>
        await _db.Courses.Include(c => c.Teacher).FirstOrDefaultAsync(c => c.Id == id);

    public async Task<List<Course>> GetFilteredAsync(string? name, int? teacherId, int? minCredits, int? maxCredits)
    {
        var query = _db.Courses.AsNoTracking().Include(c => c.Teacher).AsQueryable();

        if (!string.IsNullOrWhiteSpace(name))
            query = query.Where(c => c.Name.Contains(name));
        if (teacherId.HasValue)
            query = query.Where(c => c.TeacherId == teacherId.Value);
        if (minCredits.HasValue)
            query = query.Where(c => c.Credits >= minCredits.Value);
        if (maxCredits.HasValue)
            query = query.Where(c => c.Credits <= maxCredits.Value);

        return await query.OrderBy(c => c.Name).ToListAsync();
    }
}
