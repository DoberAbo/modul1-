using aidana1moduls.Models;

namespace aidana1moduls.Repositories.Interfaces;

public interface IEnrollmentRepository : IRepository<Enrollment>
{
    Task<bool> ExistsAsync(int studentId, int courseId);
}
