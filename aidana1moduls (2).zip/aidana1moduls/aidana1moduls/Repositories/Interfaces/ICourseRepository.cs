using aidana1moduls.Models;

namespace aidana1moduls.Repositories.Interfaces;

public interface ICourseRepository : IRepository<Course>
{
    Task<List<Course>> GetFilteredAsync(string? name, int? teacherId, int? minCredits, int? maxCredits);
}
