using aidana1moduls.Models;

namespace aidana1moduls.Repositories.Interfaces;

public interface ITeacherRepository : IRepository<Teacher>
{
    Task<Teacher?> GetByEmailAsync(string email);
    Task<bool> HasCoursesAsync(int teacherId);
}
