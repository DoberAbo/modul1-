using aidana1moduls.Models;

namespace aidana1moduls.Repositories.Interfaces;

public interface IStudentRepository : IRepository<Student>
{
    Task<Student?> GetByEmailAsync(string email);
    Task<Student?> GetWithCoursesAsync(int id);
}
