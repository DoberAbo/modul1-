using System.ComponentModel.DataAnnotations;

namespace aidana1moduls.DTO.Courses;

public class CourseCreateDto
{
    [Required(ErrorMessage = "Название курса обязательно"), MaxLength(200)]
    public string Name { get; set; } = string.Empty;

    [MaxLength(1000)]
    public string? Description { get; set; }

    [Range(1, 10, ErrorMessage = "Количество кредитов должно быть от 1 до 10")]
    public int Credits { get; set; }

    [Range(1, int.MaxValue, ErrorMessage = "TeacherId должен быть положительным числом")]
    public int TeacherId { get; set; }
}
