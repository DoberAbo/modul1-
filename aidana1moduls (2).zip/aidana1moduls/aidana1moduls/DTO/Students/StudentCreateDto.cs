using System.ComponentModel.DataAnnotations;

namespace aidana1moduls.DTO.Students;

public class StudentCreateDto
{
    [Required(ErrorMessage = "Имя обязательно"), MaxLength(100)]
    public string FirstName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Фамилия обязательна"), MaxLength(100)]
    public string LastName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Email обязателен"), EmailAddress(ErrorMessage = "Некорректный формат Email"), MaxLength(200)]
    public string Email { get; set; } = string.Empty;

    [Required(ErrorMessage = "Дата рождения обязательна")]
    public DateTime? BirthDate { get; set; }
}
