using System.ComponentModel.DataAnnotations;

namespace aidana1moduls.DTO.Enrollments;

public class EnrollmentUpdateGradeDto
{
    [Required(ErrorMessage = "Оценка обязательна")]
    [Range(0, 100, ErrorMessage = "Оценка должна быть от 0 до 100")]
    public int? Grade { get; set; }
}
