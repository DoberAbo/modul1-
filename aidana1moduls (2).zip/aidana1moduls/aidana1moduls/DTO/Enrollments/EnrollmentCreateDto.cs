using System.ComponentModel.DataAnnotations;

namespace aidana1moduls.DTO.Enrollments;

public class EnrollmentCreateDto
{
    [Range(1, int.MaxValue, ErrorMessage = "StudentId должен быть положительным числом")]
    public int StudentId { get; set; }

    [Range(1, int.MaxValue, ErrorMessage = "CourseId должен быть положительным числом")]
    public int CourseId { get; set; }
}
